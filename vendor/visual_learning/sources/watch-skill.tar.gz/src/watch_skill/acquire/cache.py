"""Content-addressed download cache: never re-download an unchanged video.

Layout: ``<data_dir>/cache/<key>/`` where ``key`` is a hash of the normalized
source URL. Each entry holds the media file(s), optional subtitles, and an
``entry.json`` with source metadata. Access time is tracked by touching
``entry.json`` so LRU eviction can order entries without OS atime support.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from watch_skill.config import get_settings

ENTRY_FILE = "entry.json"


@dataclass
class CacheEntry:
    """One cached download."""

    key: str
    dir: Path
    video_path: Path | None
    subtitle_path: Path | None
    info: dict[str, Any]
    # Digest of the committed media plus the stat it had at commit time. A hit
    # whose stat still matches skips re-hashing a multi-gigabyte download; a
    # hit whose stat has drifted is re-hashed rather than trusted.
    content_digest: str | None = None
    committed_stat: dict[str, Any] | None = None


def cache_key(source: str) -> str:
    """Stable key for a source URL (case-preserved, whitespace-trimmed)."""
    return hashlib.sha256(source.strip().encode("utf-8")).hexdigest()[:24]


def entry_dir(source: str, create: bool = False) -> Path:
    """Directory where this source's download lives (created on demand)."""
    directory = get_settings().cache_dir / cache_key(source)
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory


def _load_entry(directory: Path) -> CacheEntry | None:
    meta_path = directory / ENTRY_FILE
    if not meta_path.is_file():
        return None
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    video = directory / meta["video"] if meta.get("video") else None
    subs = directory / meta["subtitle"] if meta.get("subtitle") else None
    if video is not None and not video.is_file():
        return None
    return CacheEntry(
        key=directory.name,
        dir=directory,
        video_path=video,
        subtitle_path=subs if subs and subs.is_file() else None,
        info=meta.get("info", {}),
        content_digest=meta.get("content_digest"),
        committed_stat=meta.get("committed_stat"),
    )


def lookup(source: str) -> CacheEntry | None:
    """Return the cached entry for ``source`` and mark it recently used."""
    directory = entry_dir(source)
    entry = _load_entry(directory)
    if entry is not None:
        try:
            os.utime(directory / ENTRY_FILE)
        except OSError:
            pass
    return entry


def stat_signature(path: Path) -> dict[str, Any]:
    """Size + mtime of a file — the cheap check that its bytes are untouched."""
    info = path.stat()
    return {"size": info.st_size, "mtime_ns": info.st_mtime_ns}


def digest_if_needed(entry: CacheEntry) -> str | None:
    """The cached entry's content digest, hashing only when it has to.

    A cache hit whose file still has the size and mtime it was committed with
    is byte-identical, so the stored digest stands. Anything else — a manifest
    from before digests existed, a file touched since — is re-read.
    """
    if entry.video_path is None:
        return None
    current = stat_signature(entry.video_path)
    if entry.content_digest and entry.committed_stat == current:
        return entry.content_digest
    from watch_skill.identity import digest_file  # noqa: PLC0415

    digest = digest_file(entry.video_path)
    meta_path = entry.dir / ENTRY_FILE
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        meta["content_digest"] = digest
        meta["committed_stat"] = current
        meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    except (OSError, json.JSONDecodeError):
        pass  # the digest is still correct; caching it again is an optimisation
    return digest


def commit(
    source: str,
    video_path: Path | None,
    subtitle_path: Path | None = None,
    info: dict[str, Any] | None = None,
    content_digest: str | None = None,
) -> CacheEntry:
    """Record a completed download that already lives inside the entry dir.

    Acquirers download *into* :func:`entry_dir` so committing is just writing
    the manifest — no copy of a multi-GB file.
    """
    directory = entry_dir(source, create=True)
    if content_digest is None and video_path is not None and video_path.is_file():
        from watch_skill.identity import digest_file  # noqa: PLC0415

        content_digest = digest_file(video_path)
    meta = {
        "source": source,
        "video": video_path.name if video_path else None,
        "subtitle": subtitle_path.name if subtitle_path else None,
        "info": info or {},
        "content_digest": content_digest,
        "committed_stat": (
            stat_signature(video_path)
            if video_path is not None and video_path.is_file() else None
        ),
        "committed_at": time.time(),
    }
    (directory / ENTRY_FILE).write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    evict_lru()
    return CacheEntry(
        key=directory.name,
        dir=directory,
        video_path=video_path,
        subtitle_path=subtitle_path,
        info=info or {},
        content_digest=content_digest,
        committed_stat=meta["committed_stat"],
    )


def _dir_size(directory: Path) -> int:
    return sum(p.stat().st_size for p in directory.rglob("*") if p.is_file())


def evict_lru(max_bytes: int | None = None) -> int:
    """Delete least-recently-used entries until the cache fits the cap.

    Returns the number of evicted entries. Recency = mtime of ``entry.json``
    (touched on every :func:`lookup` hit).
    """
    cap = max_bytes if max_bytes is not None else get_settings().cache_max_bytes
    cache_dir = get_settings().cache_dir
    if not cache_dir.is_dir():
        return 0

    entries: list[tuple[float, Path, int]] = []
    total = 0
    for directory in cache_dir.iterdir():
        meta = directory / ENTRY_FILE
        if not directory.is_dir() or not meta.is_file():
            continue
        size = _dir_size(directory)
        total += size
        entries.append((meta.stat().st_mtime, directory, size))

    evicted = 0
    entries.sort()  # oldest first
    while total > cap and entries:
        _, directory, size = entries.pop(0)
        shutil.rmtree(directory, ignore_errors=True)
        total -= size
        evicted += 1
    return evicted


def clear() -> None:
    """Remove the entire cache (used by `watch-skill cache clear`)."""
    shutil.rmtree(get_settings().cache_dir, ignore_errors=True)
