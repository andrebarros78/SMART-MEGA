"""Doctor checks: statuses, self-heal paths (mocked — no network), health log."""
from __future__ import annotations

import subprocess
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

from watch_skill.health import doctor
from watch_skill.health.log import read_incidents, record_incident


def _completed(stdout: str = "", returncode: int = 0) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr="")


def test_check_python_passes_here() -> None:
    result = doctor.check_python()
    assert result.status == "ok"


def test_check_ffmpeg_fail_without_fix(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: None)
    result = doctor.check_ffmpeg(fix=False)
    assert result.status == "fail"


def test_check_ffmpeg_ok_when_present(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    fake = tmp_path / "ffmpeg.exe"
    fake.write_bytes(b"")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    result = doctor.check_ffmpeg(fix=False)
    assert result.status == "ok"


def test_ffmpeg_version_reads_the_release_line() -> None:
    """Every spelling a real build uses, including the one with no number."""
    cases = {
        "ffmpeg version 9.0.1-full_build-www.gyan.dev Copyright (c)": (9, 0),
        "ffmpeg version n7.1 Copyright (c) 2000-2024": (7, 1),
        "ffmpeg version 4.4.2-0ubuntu0.22.04.1 Copyright (c)": (4, 4),
        "ffmpeg version 5.1 Copyright (c) 2000-2022": (5, 1),
        # A build from git carries a revision where the version goes, and is
        # by definition ahead of every release. Unparseable is not "too old".
        "ffmpeg version N-109621-g0c0f9b1a2e Copyright (c)": None,
        "not ffmpeg at all": None,
    }
    for banner, expected in cases.items():
        parsed = _parse_ffmpeg_banner(banner)
        assert parsed == expected, banner


def _parse_ffmpeg_banner(banner: str) -> tuple[int, int] | None:
    """Run `ffmpeg_version` against a canned banner, without an ffmpeg."""
    import subprocess as _subprocess

    original = doctor._run
    doctor._run = lambda *args, **kwargs: _completed(stdout=banner)  # type: ignore[assignment]
    try:
        return doctor.ffmpeg_version("ffmpeg")
    finally:
        doctor._run = original  # type: ignore[assignment]
        del _subprocess


def test_check_ffmpeg_warns_below_the_fps_mode_floor(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """4.4 runs the product and cannot regenerate fixtures. Say exactly that."""
    fake = tmp_path / "ffmpeg.exe"
    fake.write_bytes(b"")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    monkeypatch.setattr(doctor, "ffmpeg_version", lambda _: (4, 4))

    result = doctor.check_ffmpeg(fix=False)
    assert result.status == "warn"
    assert "4.4" in result.message
    assert "5.1" in result.message
    assert "-fps_mode" in result.message
    # A warning that reads as "your ffmpeg is broken" costs somebody an
    # afternoon replacing a working dependency.
    assert "unaffected" in result.message


def test_check_ffmpeg_ok_at_the_floor(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    fake = tmp_path / "ffmpeg.exe"
    fake.write_bytes(b"")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    monkeypatch.setattr(doctor, "ffmpeg_version", lambda _: doctor.MIN_FFMPEG_VERSION)
    assert doctor.check_ffmpeg(fix=False).status == "ok"


def test_playwright_recording_check_is_optional_without_package(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(doctor, "_playwright_ffmpeg_installed", lambda: True)
    result = doctor.check_playwright_recording(fix=False)
    assert result.status == "ok"


def test_playwright_recording_installs_missing_ffmpeg(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    states = iter([False, True])
    monkeypatch.setattr(doctor, "_playwright_ffmpeg_installed", lambda: next(states))
    monkeypatch.setattr(doctor, "_run", lambda cmd, timeout=600.0: _completed())
    result = doctor.check_playwright_recording(fix=True)
    assert result.status == "ok"
    assert result.fix_applied == "playwright-install-ffmpeg"

def test_check_yt_dlp_bootstraps_when_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    downloaded = tmp_path / "managed" / "yt-dlp.exe"

    def fake_bootstrap() -> Path:
        downloaded.parent.mkdir(parents=True, exist_ok=True)
        downloaded.write_bytes(b"fake")
        return downloaded

    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: None)
    monkeypatch.setattr(doctor.binaries, "bootstrap_yt_dlp", fake_bootstrap)
    result = doctor.check_yt_dlp(fix=True)
    assert result.status == "ok"
    assert result.fix_applied == "download"
    assert downloaded.exists()


def test_yt_dlp_version_date_parsing() -> None:
    assert doctor.yt_dlp_version_date("2025.06.30") == date(2025, 6, 30)
    assert doctor.yt_dlp_version_date("2025.06.30.123456") == date(2025, 6, 30)
    assert doctor.yt_dlp_version_date("garbage") is None
    assert doctor.yt_dlp_version_date("2025.99.99") is None


def test_freshness_ok_for_recent_version(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    fake = tmp_path / "yt-dlp.exe"
    fake.write_bytes(b"")
    recent = (datetime.now().date() - timedelta(days=3)).strftime("%Y.%m.%d")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    monkeypatch.setattr(doctor, "_run", lambda cmd, timeout=60.0: _completed(recent))
    result = doctor.check_yt_dlp_freshness(fix=False)
    assert result.status == "ok"


def test_freshness_warns_when_stale_and_update_fails(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    fake = tmp_path / "yt-dlp.exe"
    fake.write_bytes(b"")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    monkeypatch.setattr(doctor, "_run", lambda cmd, timeout=60.0: _completed("2020.01.01"))
    monkeypatch.setattr(doctor, "update_yt_dlp", lambda path: False)
    result = doctor.check_yt_dlp_freshness(fix=True)
    assert result.status == "warn"
    assert "2020.01.01" in result.message


def test_freshness_self_updates_when_stale(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    fake = tmp_path / "yt-dlp.exe"
    fake.write_bytes(b"")
    monkeypatch.setattr(doctor.binaries, "find_binary", lambda name: fake)
    monkeypatch.setattr(doctor, "_run", lambda cmd, timeout=60.0: _completed("2020.01.01"))
    monkeypatch.setattr(doctor, "update_yt_dlp", lambda path: True)
    result = doctor.check_yt_dlp_freshness(fix=True)
    assert result.status == "ok"
    assert result.fix_applied == "self-update"


def test_disk_space_check_runs() -> None:
    result = doctor.check_disk_space()
    assert result.status in ("ok", "warn")


def test_ocr_models_check_empty_and_cached(isolated_settings) -> None:
    """Doctor reports which per-script OCR models are already local."""
    result = doctor.check_ocr_models()
    assert result.status == "ok"
    assert "auto-download" in result.message

    models_dir = isolated_settings / "models" / "ocr"
    models_dir.mkdir(parents=True)
    (models_dir / "arabic_PP-OCRv4_rec_mobile.onnx").write_bytes(b"x")
    (models_dir / "korean_PP-OCRv5_rec_mobile.onnx").write_bytes(b"x")
    (models_dir / "PP-OCRv6_det_small.onnx").write_bytes(b"x")  # not a script rec
    result = doctor.check_ocr_models()
    assert "arabic" in result.message and "korean" in result.message
    assert "det" not in result.message


def test_api_keys_reports_local_only_without_keys() -> None:
    result = doctor.check_api_keys()
    assert result.status == "ok"
    assert "local-only" in result.message


def test_api_keys_reports_configured_providers(monkeypatch: pytest.MonkeyPatch) -> None:
    secret = "gsk-very-secret-value"
    monkeypatch.setenv("WATCHSKILL_GROQ_API_KEY", secret)
    from watch_skill.config import reset_settings

    reset_settings()
    result = doctor.check_api_keys()
    assert "groq" in result.message
    assert secret not in result.message  # key values must never leak into output


def test_report_aggregation_and_serialization() -> None:
    report = doctor.DoctorReport(
        checks=[
            doctor.CheckResult("a", "ok", "fine"),
            doctor.CheckResult("b", "warn", "meh"),
        ]
    )
    assert report.ok is True
    report.checks.append(doctor.CheckResult("c", "fail", "broken"))
    assert report.ok is False
    payload = report.to_dict()
    assert payload["ok"] is False
    assert [c["name"] for c in payload["checks"]] == ["a", "b", "c"]


def test_health_log_roundtrip(isolated_settings: Path) -> None:
    record_incident("test", "something happened", extra_field=42)
    record_incident("test", "second")
    incidents = read_incidents()
    assert len(incidents) == 2
    assert incidents[0]["extra_field"] == 42
    assert incidents[1]["detail"] == "second"
    assert "ts" in incidents[0]


def test_server_command_never_points_into_a_venv(monkeypatch, tmp_path) -> None:
    """Regression: `watch-skill setup` wrote `watch-skill serve` into agent
    configs because the venv entry point was on PATH — invisible to every
    other app. A venv-resolved exe must fall back to `uv --directory`.

    Paths are built with the native separator: hardcoded Windows raw strings
    don't split into parts on POSIX (first Linux CI run caught this)."""
    from watch_skill.health import agents_setup as mod

    venv_exe = str(tmp_path / "proj" / ".venv" / "Scripts" / "watch_skill.EXE")
    monkeypatch.setattr(
        mod.shutil, "which",
        lambda name: venv_exe if name == "watch-skill" else None,
    )
    command, args = mod.server_command()
    assert command == "uv"
    assert args[0] == "--directory" and args[-2:] == ["watch-skill", "serve"]

    global_exe = str(tmp_path / "tools" / "bin" / "watch-skill.exe")
    monkeypatch.setattr(
        mod.shutil, "which",
        lambda name: global_exe if name == "watch-skill" else None,
    )
    assert mod.server_command() == ("watch-skill", ["serve"])
