# Watch Skill in Claude Desktop

<img src="../assets/agents/claude-desktop.webp" alt="Claude Desktop avatar presenting timestamped film frames from a CRT" width="360">

**Status: machine-configured ◐** — `watch-skill setup` wrote this config on
a real machine (existing keys preserved, backup taken) and the server
command answered MCP `initialize`; a full in-app session was not run.

## Install

```bash
uvx --from "watch-skill[standard]" watch-skill doctor
```

`uvx` fetches the package on first use and needs no checkout. Prefer a
permanent install? `pipx install "watch-skill[standard]"`, then use
`"command": "watch-skill", "args": ["serve"]` in the config below.

<details>
<summary>From source instead (contributors)</summary>

```bash
git clone https://github.com/oxbshw/watch-skill && cd watch-skill
uv sync --extra all
uv run watch-skill doctor
```

Then run `watch-skill setup`, which writes the config pointing at your
checkout rather than the published package.

</details>

## Configure

Edit `%APPDATA%\Claude\claude_desktop_config.json`
(macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "watch-skill": {
      "command": "uvx",
      "args": ["--from", "watch-skill[standard]", "watch-skill", "serve"]
    }
  }
}
```

Tip: `watch-skill setup` (see [adding it to an agent](../../README.md#start-here))
detects Claude Desktop and writes this for you, backing up the existing file.

## Smoke test (3 steps)

1. Fully quit and restart Claude Desktop (tray icon too), then check the
   tools icon (🔨) lists `watch-skill`.
2. Ask: *"Watch https://www.youtube.com/watch?v=aqz-KE-bpKQ with watch-skill — what happens at 0:10?"*
3. Follow up: *"Search my videos for 'butterfly'"* — should hit `search_videos`.
