import { existsSync } from 'node:fs';
import type * as FsPromises from 'node:fs/promises';
import { appendFile, copyFile, readFile, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { FIXTURES_DIR, createTestImage } from '../../test/helpers/index.js';
import type { IAnalysisResult } from '../types.js';
import {
  readAnalysisSidecar,
  sidecarsEnabled,
  transcriptToVtt,
  writeAnalysisSidecars,
} from './analysis-sidecar.js';
import { cleanupTempDir, createTempDir } from './temp-files.js';
import { parseVtt } from './vtt-parser.js';

// Lets one test make the .vtt write fail for a NON-EEXIST reason; every other
// write (and every other test) passes straight through to the real fs.
const failVtt = vi.hoisted(() => ({ code: null as string | null }));
vi.mock('node:fs/promises', async (importOriginal) => {
  const actual = await importOriginal<typeof FsPromises>();
  return {
    ...actual,
    writeFile: async (path: unknown, data: unknown, opts: unknown) => {
      if (failVtt.code && String(path).endsWith('.vtt')) {
        throw Object.assign(new Error('denied'), { code: failVtt.code });
      }
      return actual.writeFile(path as never, data as never, opts as never);
    },
  };
});

function fakeResult(framePath: string): IAnalysisResult {
  return {
    metadata: {
      platform: 'local',
      title: 'clip.mp4',
      duration: 3,
      durationFormatted: '0:03',
      url: 'clip.mp4',
    },
    transcript: [{ time: '0:01', speaker: 'Ana', text: 'preço imperdível' }],
    frames: [{ time: '0:01', filePath: framePath, mimeType: 'image/jpeg' }],
    comments: [],
    chapters: [],
    ocrResults: [{ time: '0:01', text: 'R$ 99', confidence: 90 }],
    timeline: [],
    warnings: [],
  };
}

const PARAMS = { detail: 'standard', maxFrames: 20, threshold: 0.1 };

describe('transcriptToVtt', () => {
  it('round-trips text and speaker through parseVtt', () => {
    const vtt = transcriptToVtt([
      { time: '0:00', text: 'Olá' },
      { time: '0:05', speaker: 'Ana', text: 'tudo bem?' },
    ]);
    expect(vtt.startsWith('WEBVTT')).toBe(true);

    const parsed = parseVtt(vtt);
    expect(parsed).toEqual([
      { time: '0:00', endTime: '0:05', text: 'Olá' },
      { time: '0:05', endTime: '0:08', speaker: 'Ana', text: 'tudo bem?' },
    ]);
  });

  it('defaults the last cue to start + 3s', () => {
    const parsed = parseVtt(transcriptToVtt([{ time: '0:10', text: 'só uma' }]));
    expect(parsed[0]).toEqual({ time: '0:10', endTime: '0:13', text: 'só uma' });
  });

  it('honors an explicit endTime over the next cue start', () => {
    const parsed = parseVtt(
      transcriptToVtt([
        { time: '0:00', endTime: '0:10', text: 'longo' },
        { time: '0:02', text: 'depois' },
      ]),
    );
    expect(parsed[0].endTime).toBe('0:10');
  });

  it('clamps to a minimum 1s cue when two entries share a timestamp', () => {
    const parsed = parseVtt(
      transcriptToVtt([
        { time: '0:05', text: 'a' },
        { time: '0:05', text: 'b' },
      ]),
    );
    // end = max(nextStart 5, start + 1 = 6) → 0:06, never a zero/negative cue.
    expect(parsed[0].endTime).toBe('0:06');
  });
});

describe('sidecar write/read', () => {
  beforeEach(() => {
    vi.stubEnv('MCP_WRITE_SIDECARS', '1');
  });
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it('does nothing when MCP_WRITE_SIDECARS is off', async () => {
    vi.stubEnv('MCP_WRITE_SIDECARS', '0');
    expect(sidecarsEnabled()).toBe(false);
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      const { written, failed } = await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, {
        transcriptFromWhisper: true,
      });
      expect(written).toEqual([]);
      expect(failed).toBe(false);
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('persists analysis + frames + vtt and reads them back when valid', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');

      const { written } = await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, {
        transcriptFromWhisper: true,
      });
      expect(written.length).toBe(3);
      expect(existsSync(join(tempDir, 'clip.analysis.json'))).toBe(true);
      expect(existsSync(join(tempDir, 'clip.frames'))).toBe(true);
      expect(existsSync(join(tempDir, 'clip.vtt'))).toBe(true);

      const read = await readAnalysisSidecar(clip, PARAMS);
      expect(read).not.toBeNull();
      expect(read?.transcript).toHaveLength(1);
      expect(read?.ocrResults).toHaveLength(1);
      expect(read?.frames).toHaveLength(1);
      // Frame path was rewritten into the durable sibling dir and still exists.
      expect(read?.frames[0].filePath).toContain('clip.frames');
      expect(existsSync(read?.frames[0].filePath ?? '')).toBe(true);
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('drops frames whose image file vanished after the sidecar was written', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, {
        transcriptFromWhisper: false,
      });

      // Delete the durable copy the sidecar points at.
      await rm(join(tempDir, 'clip.frames', 'frame_001.jpg'), { force: true });

      const read = await readAnalysisSidecar(clip, PARAMS);
      expect(read).not.toBeNull();
      expect(read?.frames).toHaveLength(0); // the now-missing frame is dropped
      expect(read?.ocrResults).toHaveLength(1); // text data is unaffected
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('invalidates on differing params', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, { transcriptFromWhisper: true });

      const read = await readAnalysisSidecar(clip, { ...PARAMS, detail: 'detailed' });
      expect(read).toBeNull();
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('round-trips adaptive-default params (maxFrames absent vs present-undefined)', async () => {
    // The invariant: JSON.stringify drops undefined-valued keys symmetrically on
    // the write path and the compare path. A refactor of sameParams to key-set
    // comparison would break every adaptive-default sidecar — this pins it.
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');

      const adaptiveParams = { detail: 'standard', maxFrames: undefined, threshold: 0.1 };
      await writeAnalysisSidecars(clip, fakeResult(frame), adaptiveParams, {
        transcriptFromWhisper: true,
      });

      const read = await readAnalysisSidecar(clip, { detail: 'standard', threshold: 0.1 });
      expect(read).not.toBeNull();
      expect(read?.transcript).toHaveLength(1);
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('invalidates an old fixed-budget sidecar (maxFrames: 20) for adaptive-default params', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      // Simulates a sidecar written by v0.5 (fixed maxFrames persisted).
      await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, { transcriptFromWhisper: true });

      const read = await readAnalysisSidecar(clip, { detail: 'standard', threshold: 0.1 });
      expect(read).toBeNull(); // effective budget now differs per duration → recompute
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('invalidates a sidecar written at a different frame width', async () => {
    // maxWidth changes the persisted frame images, so a sidecar written at one
    // width must not answer a request for another — with MCP_WRITE_SIDECARS the
    // staleness would otherwise outlive the process, not just the 10min cache.
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      await writeAnalysisSidecars(
        clip,
        fakeResult(frame),
        { ...PARAMS, maxWidth: 0 },
        {
          transcriptFromWhisper: false,
        },
      );

      expect(await readAnalysisSidecar(clip, { ...PARAMS, maxWidth: 1920 })).toBeNull();
      expect(await readAnalysisSidecar(clip, PARAMS)).toBeNull(); // the 800px default
      expect(await readAnalysisSidecar(clip, { ...PARAMS, maxWidth: 0 })).not.toBeNull();
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('keys on skipFrames; the canonical framed shape (no entry) answers framed reads', async () => {
    // skipFrames: true is present in the key; false resolves to an absent
    // entry (`|| undefined` in resultDefiningParams), so all framed calls
    // share one canonical shape. Pre-#29 sidecars also lack the entry but are
    // retired wholesale by SIDECAR_VERSION 2 (see the poisoned-sidecar test).
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');

      // A legacy (pre-#29, framed) sidecar: key has no skipFrames entry.
      await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, { transcriptFromWhisper: true });
      expect(await readAnalysisSidecar(clip, { ...PARAMS, skipFrames: true })).toBeNull();
      expect(await readAnalysisSidecar(clip, PARAMS)).not.toBeNull(); // back-compat pin

      // A frameless sidecar must not answer a framed read either.
      await writeAnalysisSidecars(
        clip,
        { ...fakeResult(frame), frames: [] },
        { ...PARAMS, skipFrames: true },
        { transcriptFromWhisper: true },
      );
      expect(await readAnalysisSidecar(clip, PARAMS)).toBeNull();
      expect(await readAnalysisSidecar(clip, { ...PARAMS, skipFrames: true })).not.toBeNull();
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('rejects a poisoned pre-#29 (version 1) frameless sidecar on a framed read', async () => {
    // The upgrade hazard PR #34 review caught: pre-fix code never keyed
    // skipFrames, so a frameless run under ≤0.7.1 with MCP_WRITE_SIDECARS=1
    // persisted frames: [] under params WITHOUT a skipFrames entry — the very
    // shape a post-fix framed read (false → absent key) produces. Only the
    // version gate can invalidate those retroactively; this reconstructs that
    // exact on-disk shape (real writer output, version forced to 1) and
    // demands a recompute instead of a zero-frame disk hit.
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      await writeAnalysisSidecars(
        clip,
        { ...fakeResult(frame), frames: [] },
        PARAMS, // pre-fix frameless key: no skipFrames entry
        { transcriptFromWhisper: true },
      );
      const jsonPath = join(tempDir, 'clip.analysis.json');
      const persisted = JSON.parse(await readFile(jsonPath, 'utf8'));
      persisted.version = 1;
      await writeFile(jsonPath, JSON.stringify(persisted));

      expect(await readAnalysisSidecar(clip, PARAMS)).toBeNull();
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('invalidates when the source video changes (stamp mismatch)', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');
      await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, { transcriptFromWhisper: true });

      await appendFile(clip, Buffer.from([0, 1, 2, 3])); // changes size → new stamp
      const read = await readAnalysisSidecar(clip, PARAMS);
      expect(read).toBeNull();
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('never overwrites an existing .vtt and skips it for non-Whisper transcripts', async () => {
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');

      // transcriptFromWhisper=false → no .vtt is written at all.
      const { written } = await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, {
        transcriptFromWhisper: false,
      });
      expect(written).not.toContain(join(tempDir, 'clip.vtt'));
      expect(existsSync(join(tempDir, 'clip.vtt'))).toBe(false);

      // A pre-existing .vtt (e.g. the user's own GPU transcript) is preserved.
      // The write is create-exclusive ('wx'), so this exercises the EEXIST path:
      // the file is neither clobbered nor reported as written, and EEXIST must
      // NOT surface as failed — an existing .vtt is the documented no-op.
      const userVtt = join(tempDir, 'clip.vtt');
      await writeFile(userVtt, 'WEBVTT\n\nUSER CONTENT', 'utf8');
      const second = await writeAnalysisSidecars(clip, fakeResult(frame), PARAMS, {
        transcriptFromWhisper: true,
      });
      const { readFile } = await import('node:fs/promises');
      expect(await readFile(userVtt, 'utf8')).toContain('USER CONTENT');
      expect(second.written).not.toContain(userVtt);
      expect(second.failed).toBe(false);
    } finally {
      await cleanupTempDir(tempDir);
    }
  });

  it('reports failed with a reason when the .vtt write fails for a real reason', async () => {
    // The rethrow half of the EEXIST filter. Without a test here, simplifying
    // that line to a bare `catch {}` — which reads as harmless next to a
    // comment saying "an existing .vtt is a no-op" — turns every genuine write
    // failure into a silent success. (Pre-creating a DIRECTORY at the path is
    // not a substitute: O_CREAT|O_EXCL returns EEXIST for one, so it lands in
    // the no-op branch instead.)
    const tempDir = await createTempDir();
    try {
      const clip = join(tempDir, 'clip.mp4');
      await copyFile(join(FIXTURES_DIR, 'tiny.mp4'), clip);
      const frame = await createTestImage(tempDir, 'frame.jpg');

      failVtt.code = 'EACCES';
      const { written, failed, reason } = await writeAnalysisSidecars(
        clip,
        fakeResult(frame),
        PARAMS,
        { transcriptFromWhisper: true },
      );

      expect(failed).toBe(true);
      expect(written).not.toContain(join(tempDir, 'clip.vtt'));
      // The .vtt is written LAST, so the authoritative .analysis.json is
      // already on disk — the caller needs that to avoid telling the user
      // nothing was persisted.
      expect(written).toContain(join(tempDir, 'clip.analysis.json'));
      expect(reason).toBeTruthy();
      expect(reason).not.toContain(tempDir); // no filesystem paths in warnings[]
    } finally {
      failVtt.code = null;
      await cleanupTempDir(tempDir);
    }
  });

  it('round-trips text containing angle brackets through the .vtt sidecar', async () => {
    // transcriptToVtt escapes '&' and '<' (WebVTT requires it) and parseVtt
    // decodes them, so a transcript is not quietly rewritten by being persisted
    // and read back. Before the escape existed, the '<' was written raw and the
    // strip deleted it on the next run.
    const entries = [{ time: '0:00', speaker: 'a<b', text: '5 < 10 && 10 > 5' }];
    expect(parseVtt(transcriptToVtt(entries))).toEqual([
      { time: '0:00', endTime: '0:03', speaker: 'a<b', text: '5 < 10 && 10 > 5' },
    ]);
  });

  it('returns null for non-local sources', async () => {
    const read = await readAnalysisSidecar('https://www.loom.com/share/abc123', PARAMS);
    expect(read).toBeNull();
  });
});
