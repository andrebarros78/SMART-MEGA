import { execFile as execFileCb } from 'node:child_process';
import { mkdtemp, readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { extname, join } from 'node:path';
import { promisify } from 'node:util';
import type { IFrameResult } from '../types.js';

const execFile = promisify(execFileCb);

const require = createRequire(import.meta.url);
const ffmpegPath: string = require('ffmpeg-static') as string;

/** Normalize path to forward slashes for ffmpeg image2 muxer (Windows compat) */
function ffmpegPath_(p: string): string {
  return p.replace(/\\/g, '/');
}

export function parseTimestamp(ts: string): number {
  const parts = ts.split(':').map(Number);
  if (parts.some((p) => isNaN(p))) {
    throw new Error(`Invalid timestamp format: "${ts}"`);
  }

  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  throw new Error(`Invalid timestamp format: "${ts}". Expected "M:SS" or "H:MM:SS".`);
}

export function formatTimestamp(seconds: number, fractionalDigits = 0): string {
  if (fractionalDigits > 0) seconds = Number(seconds.toFixed(fractionalDigits));
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const fraction =
    fractionalDigits > 0
      ? (seconds - Math.floor(seconds))
          .toFixed(fractionalDigits)
          .slice(1)
          .replace(/0+$/, '')
          .replace(/\.$/, '')
      : '';

  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}${fraction}`;
  }
  return `${mins}:${String(secs).padStart(2, '0')}${fraction}`;
}

/**
 * An ffmpeg that died on a SIGNAL crashed; it did not "find no frames".
 *
 * The distinction is invisible everywhere else in this pipeline, because both
 * outcomes arrive as a rejected promise and degrade to an empty result. That
 * matters concretely: the bundled `ffmpeg-static` 7.0.2 LINUX build segfaults
 * in the MPEG-TS demuxer, so every `.mts`/`.m2ts` input — the standard AVCHD
 * camcorder format — returns zero frames in the published Docker image. The
 * identical bytes parse fine on the Windows build, so this is the binary, not
 * the file. Without this message the user sees an empty result and no reason.
 *
 * Returns `null` for an ordinary non-zero exit, which callers already handle.
 * The reason deliberately omits the command line (CLAUDE.md: a surfaced ffmpeg
 * failure must be path-free) — `e.message` on a signal death is the full
 * argv plus ffmpeg's banner.
 */
function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export function ffmpegCrashReason(error: unknown, videoPath: string): string | null {
  const signal =
    error && typeof error === 'object' && 'signal' in error
      ? (error as { signal?: string | null }).signal
      : null;
  if (!signal) return null;

  const ext = extname(videoPath).toLowerCase() || 'this container';
  return (
    `ffmpeg crashed (${signal}) while reading ${ext} — the bundled ffmpeg binary ` +
    `cannot demux this container on this platform. Convert the file to .mp4 or ` +
    `.mkv and retry.`
  );
}

export async function probeVideoDuration(videoPath: string): Promise<number> {
  try {
    const { stderr } = await execFile(ffmpegPath, ['-i', videoPath, '-f', 'null', '-'], {
      timeout: 30000,
    });
    return parseDurationFromStderr(stderr);
  } catch (error: unknown) {
    // ffmpeg exits with code 1 even on successful probe; check stderr
    if (error && typeof error === 'object' && 'stderr' in error) {
      const stderr = (error as { stderr: string }).stderr;
      const duration = parseDurationFromStderr(stderr);
      if (duration > 0) return duration;
    }
    const crash = ffmpegCrashReason(error, videoPath);
    if (crash) throw new Error(crash, { cause: error });
    throw new Error(`Failed to probe video duration: ${videoPath}`, { cause: error });
  }
}

function parseDurationFromStderr(stderr: string): number {
  const match = stderr.match(/Duration:\s*(\d+):(\d+):(\d+)\.(\d+)/);
  if (!match) return 0;

  const hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const seconds = parseInt(match[3], 10);
  const centiseconds = parseInt(match[4], 10);

  return hours * 3600 + minutes * 60 + seconds + centiseconds / 100;
}

export interface IVideoProbeResult {
  duration: number;
  width?: number;
  height?: number;
  fps?: number;
  videoCodec?: string;
  hasAudio: boolean;
  audioCodec?: string;
  creationTime?: string;
}

/**
 * Probe a video file's metadata by parsing ffmpeg's stderr.
 *
 * `ffmpeg-static` doesn't ship `ffprobe`, so we invoke ffmpeg with no output
 * — it prints stream info to stderr and exits with code 1 ("At least one
 * output file must be specified"). This is the same trick `probeVideoDuration`
 * uses; we just parse more fields.
 */
export async function probeVideo(videoPath: string): Promise<IVideoProbeResult> {
  let stderr: string;
  try {
    ({ stderr } = await execFile(ffmpegPath, ['-i', videoPath], { timeout: 30000 }));
  } catch (error: unknown) {
    if (error && typeof error === 'object' && 'stderr' in error) {
      stderr = (error as { stderr: string }).stderr;
    } else {
      throw new Error(`Failed to probe video: ${videoPath}`, { cause: error });
    }
  }

  // ffmpeg only prints "Input #N, ..." when it successfully opens the file.
  // If that line is missing, the path was bad / format unrecognized — surface
  // the error rather than returning a half-empty result.
  if (!/^Input #\d+/m.test(stderr)) {
    throw new Error(`Failed to probe video: ${videoPath}`);
  }

  return parseProbeFromStderr(stderr);
}

export function parseProbeFromStderr(stderr: string): IVideoProbeResult {
  const result: IVideoProbeResult = {
    duration: parseDurationFromStderr(stderr),
    hasAudio: false,
  };

  // Only parse the input section — ffmpeg may also print output streams.
  const inputSection = stderr.split(/^Output #\d+/m)[0];

  const videoMatch = inputSection.match(
    /Stream #\d+:\d+(?:[^:]*)?: Video: (\S+?)(?:\s|,)[^\n]*?(\d{2,5})x(\d{2,5})/,
  );
  if (videoMatch) {
    result.videoCodec = videoMatch[1].replace(/,$/, '');
    result.width = parseInt(videoMatch[2], 10);
    result.height = parseInt(videoMatch[3], 10);
  }

  // fps lives on the same Video line, but ffmpeg omits it for some streams
  // (variable-frame-rate / certain MKV/MOV exports print only tbr/tbn).
  // Parse it independently so a missing fps doesn't drop codec/resolution above.
  const fpsMatch = inputSection.match(/: Video:[^\n]*?(\d+(?:\.\d+)?)\s*fps/);
  if (fpsMatch) {
    result.fps = parseFloat(fpsMatch[1]);
  }

  const audioMatch = inputSection.match(/Stream #\d+:\d+(?:[^:]*)?: Audio: (\S+?)(?:\s|,)/);
  if (audioMatch) {
    result.hasAudio = true;
    result.audioCodec = audioMatch[1].replace(/,$/, '');
  }

  const creationMatch = inputSection.match(/creation_time\s*:\s*(\S+)/);
  if (creationMatch) {
    result.creationTime = creationMatch[1];
  }

  return result;
}

export function parseSceneTimestamps(stderr: string): number[] {
  const timestamps: number[] = [];
  const regex = /pts_time:(\d+(?:\.\d+)?)/g;
  let match;

  while ((match = regex.exec(stderr)) !== null) {
    timestamps.push(parseFloat(match[1]));
  }

  return timestamps;
}

export async function extractSceneFrames(
  videoPath: string,
  outputDir: string,
  options: { threshold?: number; maxFrames?: number } = {},
): Promise<IFrameResult[]> {
  const threshold = options.threshold ?? 0.1;
  const maxFrames = options.maxFrames ?? 20;

  const outputPattern = ffmpegPath_(join(outputDir, 'scene_%03d.jpg'));

  try {
    const { stderr } = await execFile(
      ffmpegPath,
      [
        '-i',
        videoPath,
        '-vf',
        `select='gt(scene,${threshold})',showinfo`,
        '-fps_mode',
        'vfr',
        '-q:v',
        '2',
        outputPattern,
        '-y',
      ],
      { timeout: 120000 },
    );

    const timestamps = parseSceneTimestamps(stderr);
    const files = await listFrameFiles(outputDir, 'scene_');

    const results: IFrameResult[] = files.slice(0, maxFrames).map((file, i) => ({
      time: formatTimestamp(timestamps[i] ?? 0),
      filePath: join(outputDir, file),
      mimeType: 'image/jpeg',
    }));

    return results;
  } catch (error: unknown) {
    // Try to parse results from partial output
    if (error && typeof error === 'object' && 'stderr' in error) {
      const stderr = (error as { stderr: string }).stderr;
      const timestamps = parseSceneTimestamps(stderr);
      const files = await listFrameFiles(outputDir, 'scene_').catch(() => [] as string[]);

      if (files.length > 0) {
        return files.slice(0, maxFrames).map((file, i) => ({
          time: formatTimestamp(timestamps[i] ?? 0),
          filePath: join(outputDir, file),
          mimeType: 'image/jpeg',
        }));
      }
    }

    const msg = ffmpegCrashReason(error, videoPath) ?? errorMessage(error);
    throw new Error(`Scene frame extraction failed: ${msg}`, { cause: error });
  }
}

export async function extractFrameAt(
  videoPath: string,
  outputDir: string,
  timestamp: string,
): Promise<IFrameResult> {
  const seconds = parseTimestamp(timestamp);
  const outputPath = ffmpegPath_(join(outputDir, `frame_at_${seconds}.jpg`));

  try {
    await execFile(
      ffmpegPath,
      ['-ss', String(seconds), '-i', videoPath, '-frames:v', '1', '-q:v', '2', outputPath, '-y'],
      { timeout: 30000 },
    );
  } catch (error: unknown) {
    const msg = ffmpegCrashReason(error, videoPath) ?? errorMessage(error);
    throw new Error(`Frame extraction at ${timestamp} failed: ${msg}`, { cause: error });
  }

  return {
    time: timestamp,
    filePath: outputPath,
    mimeType: 'image/jpeg',
  };
}

export async function extractFrameBurst(
  videoPath: string,
  outputDir: string,
  from: string,
  to: string,
  count = 5,
): Promise<IFrameResult[]> {
  const fromSeconds = parseTimestamp(from);
  const toSeconds = parseTimestamp(to);

  if (toSeconds <= fromSeconds) {
    throw new Error(`"to" timestamp (${to}) must be after "from" timestamp (${from}).`);
  }

  const duration = toSeconds - fromSeconds;
  const fps = count / duration;

  // Count only this invocation's JPEGs, even when the caller reuses outputDir.
  const burstDir = await mkdtemp(join(outputDir, 'burst-'));
  const outputPattern = ffmpegPath_(join(burstDir, 'burst_%03d.jpg'));
  let timestamps: number[];

  try {
    const { stderr } = await execFile(
      ffmpegPath,
      [
        '-copyts',
        '-start_at_zero',
        '-ss',
        String(fromSeconds),
        '-to',
        String(toSeconds),
        '-i',
        videoPath,
        '-vf',
        // Select real source frames rather than rewriting their PTS with fps.
        // One frame at/after each sampling slot; never synthesize duplicates.
        `select='gte(t-${fromSeconds}+0.000001,selected_n/${fps})',showinfo`,
        '-fps_mode',
        'vfr',
        '-frames:v',
        String(count),
        '-q:v',
        '2',
        outputPattern,
        '-y',
      ],
      { timeout: 60000 },
    );
    // showinfo's pts_time is printed with limited significant digits. Use the
    // integer PTS and time base so long clips do not lose subsecond precision.
    const timeBase = /config in time_base:\s*(\d+)\/(\d+)/.exec(stderr);
    if (!timeBase) throw new Error('Missing burst frame time base');
    timestamps = Array.from(
      stderr.matchAll(/\bn:\s*\d+\s+pts:\s*(-?\d+)/g),
      (match) => (Number(match[1]) * Number(timeBase[1])) / Number(timeBase[2]),
    );
  } catch (error: unknown) {
    // Keep diagnostics in the internal cause, never in the public message.
    throw new Error('Burst frame extraction failed.', { cause: error });
  }

  const files = await listFrameFiles(burstDir, 'burst_');
  if (timestamps.length < files.length) {
    throw new Error('Burst frame timestamp metadata is incomplete.');
  }

  return files.slice(0, count).map((file, i) => {
    return {
      time: formatTimestamp(timestamps[i], 6),
      timingOrigin: 'source-pts',
      filePath: join(burstDir, file),
      mimeType: 'image/jpeg',
    };
  });
}

/**
 * Extract frames at a fixed rate (dense sampling).
 * Useful for "watching" the full video — captures 1 frame per second by default.
 */
export async function extractDenseFrames(
  videoPath: string,
  outputDir: string,
  options?: { fps?: number; maxFrames?: number },
): Promise<IFrameResult[]> {
  const requestedFps = options?.fps ?? 1;
  const maxFrames = options?.maxFrames ?? 60;

  // Probe duration to cap frame count
  const duration = await probeVideoDuration(videoPath);
  const expectedFrames = Math.ceil(duration * requestedFps);
  const effectiveFps = expectedFrames > maxFrames ? maxFrames / duration : requestedFps;

  const outputPattern = ffmpegPath_(join(outputDir, 'dense_%04d.jpg'));

  try {
    await execFile(
      ffmpegPath,
      ['-i', videoPath, '-vf', `fps=${effectiveFps}`, '-q:v', '2', outputPattern, '-y'],
      { timeout: 180000 },
    );
  } catch (error: unknown) {
    const msg = ffmpegCrashReason(error, videoPath) ?? errorMessage(error);
    throw new Error(`Dense frame extraction failed: ${msg}`, { cause: error });
  }

  const files = await listFrameFiles(outputDir, 'dense_');

  return files.slice(0, maxFrames).map((file, i) => ({
    time: formatTimestamp(Math.round(i / effectiveFps)),
    filePath: join(outputDir, file),
    mimeType: 'image/jpeg',
  }));
}

export interface KeyFrameExtraction {
  frames: IFrameResult[];
  /** Non-fatal messages to surface to the caller (graceful-degradation pattern). */
  warnings: string[];
}

/**
 * Extract key frames with a robust fallback chain for local files and downloads.
 *
 * - `dense: true` → uniform temporal sampling (1 fps, capped at maxFrames).
 * - otherwise → scene-change detection; **if it yields zero frames** (common for
 *   static "talking-head" clips, Reels/Stories where only an on-screen text
 *   overlay changes), fall back to uniform sampling. Uniform sampling is also
 *   strictly better for OCR of static overlays, so the fallback improves results
 *   rather than merely avoiding an empty response.
 *
 * Never throws: extraction errors degrade to `[]` with a warning, matching the
 * project's graceful-degradation convention.
 */
export async function extractKeyFrames(
  videoPath: string,
  outputDir: string,
  options: { threshold?: number; maxFrames?: number; dense?: boolean } = {},
): Promise<KeyFrameExtraction> {
  const { threshold, maxFrames, dense = false } = options;
  const warnings: string[] = [];

  // A crashed ffmpeg reports itself; anything else keeps the original message.
  // The inner extractors already prefix their own label, so don't add it twice.
  const reason = (e: unknown) => ffmpegCrashReason(e, videoPath) ?? errorMessage(e);
  const labelled = (label: string, e: unknown) => {
    const msg = reason(e);
    return msg.startsWith(label) ? msg : `${label}: ${msg}`;
  };

  const dropToWarning = (label: string) => (e: unknown) => {
    warnings.push(labelled(label, e));
    return [] as IFrameResult[];
  };

  if (dense) {
    const frames = await extractDenseFrames(videoPath, outputDir, { maxFrames }).catch(
      dropToWarning('Dense frame extraction failed'),
    );
    return { frames, warnings };
  }

  let sceneErrored = false;
  let frames = await extractSceneFrames(videoPath, outputDir, { threshold, maxFrames }).catch(
    (e: unknown) => {
      warnings.push(labelled('Scene frame extraction failed', e));
      sceneErrored = true;
      return [] as IFrameResult[];
    },
  );

  if (frames.length === 0) {
    frames = await extractDenseFrames(videoPath, outputDir, { maxFrames }).catch(
      dropToWarning('Dense frame extraction failed'),
    );
    if (frames.length > 0) {
      // Distinguish "scene detection found no cuts" (the common, expected case
      // for static clips) from "scene detection errored" — the message would
      // otherwise read as if a real ffmpeg error were simply an absence of cuts.
      warnings.push(
        sceneErrored
          ? 'Scene detection failed; fell back to uniform temporal sampling.'
          : 'No scene cuts detected; used uniform temporal sampling (better for static clips and on-screen text OCR).',
      );
    }
  }

  return { frames, warnings };
}

async function listFrameFiles(dir: string, prefix: string): Promise<string[]> {
  const files = await readdir(dir);
  return files.filter((f) => f.startsWith(prefix) && f.endsWith('.jpg')).sort();
}
