"""Execute and trace real Red Team scenarios in an isolated data directory."""
from __future__ import annotations
import configparser
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/srv/lmcp-data/storage/workspaces/SMART-MEGA-COVERAGE-20261022T0133')
BASE = Path(str(ROOT) + '-evidence') / 'r2'
sys.path.insert(0, str(ROOT))
import smart_continuous_red_team as redteam
from smart_global_integrity import REQUIRED_GLOBAL_COVERAGE_SOURCES
from smart_product_certification import code_fingerprint
from smart_source_identity import sha256_source_file
from run_smart_coverage_partition import scientific_snapshot


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()


def main():
    out = BASE / 'redteam'
    out.mkdir(exist_ok=False)
    assert git('status', '--porcelain') == ''
    before = code_fingerprint(ROOT)
    frozen = scientific_snapshot(ROOT)
    revision = git('rev-parse', 'HEAD')
    config = configparser.ConfigParser()
    config.read(ROOT / '.coveragerc')
    config['run']['parallel'] = 'False'
    config.remove_option('run', 'patch')
    config['run']['data_file'] = str(out / '.coverage')
    config['run']['include'] = '\n' + '\n'.join(str(ROOT / name) for name in REQUIRED_GLOBAL_COVERAGE_SOURCES)
    with (out / 'coverage.ini').open('w') as stream:
        config.write(stream)
    scenario_root = out / 'scenario-root'
    scenario_root.mkdir()
    for name in redteam.BEHAVIORAL_FILES:
        shutil.copyfile(ROOT / name, scenario_root / name)
    command = [sys.executable, '-m', 'coverage', 'run', '--rcfile=' + str(out / 'coverage.ini'), str(ROOT / 'smart_continuous_red_team.py')]
    env = {**os.environ, **{name: '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')}}
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    with (out / 'run.log').open('w') as log:
        result = subprocess.run(command, cwd=scenario_root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=400)
    report_path = scenario_root / redteam.REPORT_PATH
    report = json.loads(report_path.read_text())
    verified = redteam.verify_latest_report(report_path, ROOT)
    assert result.returncode == 0 and verified['status'] == 'PASS' and all(report['checks'].values())
    assert set(report['scenarios']) == set(redteam.EXPECTED_SCENARIOS)
    assert report['prospective_predictive_claim'] is False
    (out / 'REAL_RED_TEAM.json').write_bytes(report_path.read_bytes())
    subprocess.run([sys.executable, '-m', 'coverage', 'json', '--rcfile=' + str(out / 'coverage.ini'), '-o', str(out / 'coverage.raw.json')], cwd=ROOT, check=True)
    receipt = {'schema': 'SMART_FRESH_REAL_REDTEAM_COVERAGE_1', 'source_commit': revision,
               'source_fingerprint_sha256': before['sha256'], 'command': command, 'returncode': result.returncode,
               'scenario_count': len(report['scenarios']), 'all_scenarios_pass': all(report['checks'].values()),
               'report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
               'source_hashes': {name: sha256_source_file(ROOT / name) for name in REQUIRED_GLOBAL_COVERAGE_SOURCES},
               'source_fingerprint_stable': before == code_fingerprint(ROOT),
               'scientific_state_stable': frozen == scientific_snapshot(ROOT),
               'git_clean_after': git('status', '--porcelain') == '', 'github_actions_used': False,
               'started_at': started, 'completed_at': dt.datetime.now(dt.timezone.utc).isoformat()}
    assert receipt['source_fingerprint_stable'] and receipt['scientific_state_stable'] and receipt['git_clean_after']
    receipt['status'] = 'PASS'
    (out / 'RECEIPT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
