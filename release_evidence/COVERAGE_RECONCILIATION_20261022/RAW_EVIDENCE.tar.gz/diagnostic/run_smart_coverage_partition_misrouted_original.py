"""Temporary governed executor: full-case inventory, fresh coverage and raw JUnit."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path('/srv/lmcp-data/storage/workspaces/SMART-MEGA-COVERAGE-20261022T0133-evidence')
PYTHON = '/srv/lmcp-data/storage/workspaces/SMART-MEGA-FORENSIC-20261021T2048-venv/bin/python'


def git(root, *args):
    return subprocess.run(['git', *args], cwd=root, check=True, capture_output=True, text=True, timeout=45).stdout.strip()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def scientific_snapshot(root):
    paths = git(root, 'ls-files', '--', 'runtime', 'SMART_STATE_ARCHIVE', 'Mega-Sena.xlsx',
                'SMART_SIGNAL_LEDGER.json', 'SMART_ACTIVE_EPOCH.json', 'SMART_OPERATIONAL_LIFECYCLE.json',
                'SMART_NEXT_CYCLE_AUTHORITY.json', 'SMART_NEXT_CYCLE_HOLD.json').splitlines()
    rows = {name: digest(root / name) for name in paths}
    return {'files': len(rows), 'sha256': hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()}


def main():
    part = int(sys.argv[1])
    plan = json.loads((BASE / 'FRESH_PARTITION_PLAN.json').read_text())
    selected = next(row for row in plan['partitions'] if row['part'] == part)
    root = Path(selected['root'])
    out = BASE / f'full-part-{part}'
    assert out.is_dir()
    assert git(root, 'rev-parse', 'HEAD') == plan['source_commit']
    assert git(root, 'status', '--porcelain') == ''
    sys.path.insert(0, str(root))
    from smart_product_certification import code_fingerprint
    from smart_source_identity import sha256_source_file
    before = code_fingerprint(root)
    frozen_before = scientific_snapshot(root)
    assert before['sha256'] == plan['source_fingerprint_sha256']
    config = out / 'coverage.ini'
    receipt = {'schema': 'SMART_FRESH_COVERAGE_PARTITION_EXECUTION_1',
               'source_commit': plan['source_commit'], 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
               'origin': git(root, 'remote', 'get-url', 'origin'), 'part': part,
               'started_at': dt.datetime.now(dt.timezone.utc).isoformat(),
               'source_fingerprint': before, 'scientific_state_before': frozen_before,
               'expected_cases': len(selected['expected_cases']), 'github_actions_used': False}
    limits = {name: '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')}
    env = {**os.environ, **limits}
    assert env.get('GITHUB_ACTIONS', '').lower() not in {'true', '1'}
    command = [PYTHON, '-m', 'coverage', 'run', '--rcfile=' + str(config), '-m', 'pytest',
               '-q', '-p', 'no:cacheprovider', '--disable-warnings', '--durations=15',
               '--junitxml=' + str(out / 'junit.raw.xml'), '--basetemp=' + str(out / 'pytest-temp'), *selected['files']]
    receipt.update(command=command, thread_limits=limits)
    write(out / 'STARTED.json', receipt)
    with (out / 'run.log').open('w') as log:
        try:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=1100)
            receipt['pytest_exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['pytest_exit_code'] = None
            receipt['timeout'] = True
    receipt.update(completed_at=dt.datetime.now(dt.timezone.utc).isoformat(),
                   source_fingerprint_stable=before == code_fingerprint(root),
                   git_clean_after=git(root, 'status', '--porcelain') == '',
                   source_commit_stable=git(root, 'rev-parse', 'HEAD') == plan['source_commit'],
                   scientific_state_after=scientific_snapshot(root))
    receipt['scientific_state_stable'] = frozen_before == receipt['scientific_state_after']
    xml_path = out / 'junit.raw.xml'
    if xml_path.is_file():
        tree = ET.fromstring(xml_path.read_bytes())
        cases = list(tree.iter('testcase'))
        keys = [(case.get('classname'), case.get('name')) for case in cases]
        expected = [tuple(key) for key in selected['expected_cases']]
        outcomes = {tag: sum(case.find(tag) is not None for case in cases) for tag in ('failure', 'error', 'skipped')}
        receipt.update(actual_cases=len(cases), declared_tests=sum(int(s.get('tests', 0)) for s in tree.iter('testsuite')),
                       exact_inventory_match=len(keys) == len(set(keys)) == len(expected) and set(keys) == set(expected),
                       outcomes=outcomes, junit_sha256=digest(xml_path))
    for command in ([PYTHON, '-m', 'coverage', 'combine', '--rcfile=' + str(config), '--keep'],
                    [PYTHON, '-m', 'coverage', 'json', '--rcfile=' + str(config), '-o', str(out / 'coverage.raw.json')]):
        result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=60, env=env)
        receipt.setdefault('coverage_steps', []).append({'command': command, 'exit_code': result.returncode,
                                                        'stdout': result.stdout, 'stderr': result.stderr})
    raw = out / 'coverage.raw.json'
    if raw.is_file():
        report = json.loads(raw.read_text())
        for name, entry in report['files'].items():
            entry['source_sha256'] = sha256_source_file(root / name)
        write(out / 'coverage.source-bound.json', report)
        receipt['coverage_sha256'] = digest(out / 'coverage.source-bound.json')
    receipt['log_sha256'] = digest(out / 'run.log')
    receipt['status'] = 'PASS' if (receipt.get('pytest_exit_code') == 0 and receipt.get('exact_inventory_match') is True
                                    and all(receipt.get(key) is True for key in ('source_fingerprint_stable', 'git_clean_after', 'source_commit_stable', 'scientific_state_stable'))
                                    and not any(receipt.get('outcomes', {'error': 1}).values())
                                    and all(step['exit_code'] == 0 for step in receipt.get('coverage_steps', []))) else 'FAIL'
    write(out / 'RECEIPT.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ('status', 'part', 'pytest_exit_code', 'actual_cases', 'exact_inventory_match', 'outcomes', 'scientific_state_stable')}))
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
