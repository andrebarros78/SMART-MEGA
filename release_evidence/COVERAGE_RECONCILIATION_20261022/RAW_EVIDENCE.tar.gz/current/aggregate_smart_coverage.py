"""Aggregate only fresh, disjoint, source-bound, successful executions."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

import coverage

ROOT = Path('/srv/lmcp-data/storage/workspaces/SMART-MEGA-COVERAGE-20261022T0133')
BASE = Path(str(ROOT) + '-evidence') / 'r2'
sys.path.insert(0, str(ROOT))
from smart_global_integrity import REQUIRED_GLOBAL_COVERAGE_SOURCES
from smart_product_certification import code_fingerprint
from smart_regression_evidence import junit_summary
from smart_source_identity import sha256_source_file


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    plan = json.loads((BASE / 'FRESH_PARTITION_PLAN.json').read_text())
    assert code_fingerprint(ROOT)['sha256'] == plan['source_fingerprint_sha256']
    target = BASE / 'fresh-aggregate'
    target.mkdir(exist_ok=False)
    combined = coverage.CoverageData(basename=str(target / '.coverage'))
    cases, observed, parts = [], set(), []
    raw_tests, subtests = 0, 0
    for row in plan['partitions']:
        part = row['part']
        out = BASE / f'full-part-{part}'
        root = Path(row['root'])
        receipt = json.loads((out / 'RECEIPT.json').read_text())
        assert receipt['status'] == 'PASS' and receipt['pytest_exit_code'] == 0
        assert receipt['source_commit'] == plan['source_commit']
        assert receipt['source_fingerprint']['sha256'] == plan['source_fingerprint_sha256']
        assert receipt['exact_inventory_match'] is True and receipt['scientific_state_stable'] is True
        assert code_fingerprint(root) == receipt['source_fingerprint']
        assert digest(out / 'junit.raw.xml') == receipt['junit_sha256']
        assert digest(out / 'run.log') == receipt['log_sha256']
        xml = ET.fromstring((out / 'junit.raw.xml').read_bytes())
        selected = list(xml.iter('testcase'))
        keys = [(case.get('classname'), case.get('name')) for case in selected]
        assert len(keys) == len(set(keys)) == len(row['expected_cases'])
        assert set(keys) == set(map(tuple, row['expected_cases'])) and not (observed & set(keys))
        assert all(case.find(tag) is None for case in selected for tag in ('failure', 'error', 'skipped'))
        suites = list(xml.iter('testsuite'))
        declared = sum(int(s.get('tests', 0)) for s in suites)
        assert all(int(s.get(tag, 0)) == 0 for s in suites for tag in ('failures', 'errors', 'skipped'))
        logged_subtests = sum(map(int, re.findall(r'(\d+) subtests passed', (out / 'run.log').read_text())))
        assert declared - len(selected) == logged_subtests
        raw_tests += declared
        subtests += logged_subtests
        observed.update(keys)
        cases.extend(selected)
        data = coverage.CoverageData(basename=str(out / '.coverage'))
        data.read()
        for path in data.measured_files():
            assert Path(path).parent == root and Path(path).name in REQUIRED_GLOBAL_COVERAGE_SOURCES
            assert sha256_source_file(path) == sha256_source_file(ROOT / Path(path).name)
        combined.update(data, map_path=lambda path: str(ROOT / Path(path).name))
        parts.append({'part': part, 'cases': len(selected), 'raw_declared_tests': declared,
                      'passed_subtests_without_separate_testcase_nodes': logged_subtests,
                      'evidence_directory': out.name,
                      'coverage_config_sha256': digest(out / 'coverage.ini'),
                      'child_process_instrumentation': False,
                      'receipt_sha256': digest(out / 'RECEIPT.json'), 'junit_sha256': receipt['junit_sha256'],
                      'log_sha256': receipt['log_sha256']})
    extra = BASE / 'redteam'
    extra_receipt = json.loads((extra / 'RECEIPT.json').read_text())
    assert extra_receipt['status'] == 'PASS' and extra_receipt['source_commit'] == plan['source_commit']
    assert extra_receipt['source_fingerprint_sha256'] == plan['source_fingerprint_sha256']
    assert extra_receipt['scenario_count'] == 10 and extra_receipt['all_scenarios_pass'] is True
    extra_data = coverage.CoverageData(basename=str(extra / '.coverage'))
    extra_data.read()
    for path in extra_data.measured_files():
        assert Path(path).parent == ROOT and Path(path).name in REQUIRED_GLOBAL_COVERAGE_SOURCES
        assert sha256_source_file(path) == extra_receipt['source_hashes'][Path(path).name]
    combined.update(extra_data)
    assert len(cases) == plan['expected_tests']
    combined.write()
    config = target / 'coverage.ini'
    sample = (BASE / 'redteam/coverage.ini').read_text()
    config.write_text(sample.replace(str(BASE / 'redteam/.coverage'), str(target / '.coverage')))
    measurement = coverage.Coverage(config_file=str(config), data_file=str(target / '.coverage'))
    measurement.load()
    measurement.json_report(outfile=str(target / 'coverage.raw.json'))
    report = json.loads((target / 'coverage.raw.json').read_text())
    normalized = {}
    for name, entry in report['files'].items():
        source = Path(name).name
        assert source in REQUIRED_GLOBAL_COVERAGE_SOURCES and source not in normalized
        entry['source_sha256'] = sha256_source_file(ROOT / source)
        normalized[source] = entry
    assert set(normalized) == set(REQUIRED_GLOBAL_COVERAGE_SOURCES)
    report['files'] = normalized
    report['provenance'] = {'source_commit': plan['source_commit'],
                            'source_fingerprint_sha256': plan['source_fingerprint_sha256'],
                            'fresh_current_source_only': True, 'github_actions_used': False,
                            'pytest_cases': len(cases), 'partitions': parts,
                            'supplemental_real_redteam_receipt_sha256': digest(extra / 'RECEIPT.json')}
    write(target / 'SMART_COVERAGE_GLOBAL_CURRENT.json', report)
    aggregate = ET.Element('testsuites')
    suite = ET.SubElement(aggregate, 'testsuite', name='SMART full fresh regression',
                          tests=str(len(cases)), failures='0', errors='0', skipped='0')
    for case in cases:
        suite.append(case)
    junit = target / 'FULL_REGRESSION.xml'
    ET.ElementTree(aggregate).write(junit, encoding='utf-8', xml_declaration=True)
    summary = junit_summary(junit)
    assert summary['status'] == 'PASS' and summary['tests'] == plan['expected_tests']
    totals = report['totals']
    missing = {name: {'lines': entry['missing_lines'], 'branches': entry.get('missing_branches', [])}
               for name, entry in report['files'].items() if entry['missing_lines'] or entry.get('missing_branches')}
    receipt = {'schema': 'SMART_FRESH_REGRESSION_COVERAGE_AGGREGATION_1',
               'source_commit': plan['source_commit'], 'source_fingerprint_sha256': plan['source_fingerprint_sha256'],
               'tests': len(cases), 'raw_declared_tests': raw_tests, 'passed_subtests': subtests,
               'summary': summary, 'partitions': parts, 'coverage_totals': totals,
               'all_required_sources_complete': not missing, 'missing': missing,
               'coverage_sha256': digest(target / 'SMART_COVERAGE_GLOBAL_CURRENT.json'),
               'raw_junit_preserved': True,
               'junit_normalization': 'Aggregate counters rebuilt from real testcase nodes only after zero exit codes, exact independent inventory, disjoint partitions and logged passed-subtest surplus agreement. Raw reports retained unchanged; no testcase invented.',
               'historical_coverage_reused': False,
               'supplemental_real_redteam': extra_receipt,
               'completed_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'github_actions_used': False}
    write(target / 'RECEIPT.json', receipt)
    print(json.dumps({key: receipt[key] for key in ('tests', 'passed_subtests', 'coverage_totals', 'all_required_sources_complete', 'missing')}))


if __name__ == '__main__':
    main()
