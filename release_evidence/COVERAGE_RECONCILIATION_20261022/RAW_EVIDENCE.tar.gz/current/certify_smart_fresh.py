"""Validate a reconstructed certificate in a disposable same-SHA checkout."""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import uuid

ROOT = Path('/srv/lmcp-data/storage/workspaces/SMART-MEGA-COVERAGE-20261022T0133')
BASE = Path(str(ROOT) + '-evidence') / 'r2'


def git(root, *args):
    return subprocess.run(['git', *args], cwd=root, capture_output=True, text=True, check=True, timeout=60).stdout.strip()


def main():
    aggregate = BASE / 'fresh-aggregate'
    proof = json.loads((aggregate / 'RECEIPT.json').read_text())
    assert proof['all_required_sources_complete'] is True
    assert proof['summary']['status'] == 'PASS' and proof['tests'] == 1711
    tested = proof['source_commit']
    clone = ROOT.with_name(ROOT.name + '-r2-certification')
    assert not clone.exists()
    subprocess.run(['git', 'clone', '--no-hardlinks', '--branch', git(ROOT, 'branch', '--show-current'), str(ROOT), str(clone)], check=True, capture_output=True, timeout=180)
    git(clone, 'remote', 'set-url', 'origin', 'https://github.com/andrebarros78/SMART-MEGA.git')
    assert git(clone, 'rev-parse', 'HEAD') == tested and git(clone, 'status', '--porcelain') == ''
    sys.path.insert(0, str(clone))
    from smart_product_certification import code_fingerprint, verify_product_certification
    from smart_global_integrity import verify_global_integrity
    from smart_authority_freshness import audit as audit_freshness, verify_governance
    from smart_startup_reconciler import reconcile
    from run_smart_coverage_partition import scientific_snapshot
    before = scientific_snapshot(clone)
    fingerprint = code_fingerprint(clone)
    assert fingerprint['sha256'] == proof['source_fingerprint_sha256']
    coverage_path = clone / 'SMART_COVERAGE_GLOBAL_CURRENT.json'
    coverage_path.write_bytes((aggregate / coverage_path.name).read_bytes())
    identity = str(uuid.uuid4())
    env = {**os.environ, 'SMART_MEGA_CERTIFICATION_APPROVAL': tested,
           **{name: '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')}}
    command = [sys.executable, 'smart_github_certify.py', '--candidate', str(aggregate / 'FULL_REGRESSION.xml'),
               '--source-commit', tested, '--execution-id', identity]
    with (BASE / 'CERTIFICATION.log').open('w') as log:
        result = subprocess.run(command, cwd=clone, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=500)
    receipt = {'schema': 'SMART_FRESH_CONSTRUCTION_REBUILD_1', 'source_commit': tested,
               'source_fingerprint_sha256': fingerprint['sha256'], 'execution_id': identity,
               'executor_host': socket.gethostname(), 'command': command, 'returncode': result.returncode,
               'source_fingerprint_stable': fingerprint == code_fingerprint(clone),
               'scientific_state_unchanged': before == scientific_snapshot(clone),
               'changed_files': git(clone, 'diff', '--name-only').splitlines(), 'github_actions_used': False,
               'completed_at': dt.datetime.now(dt.timezone.utc).isoformat()}
    if result.returncode == 0:
        receipt.update(product=verify_product_certification(clone / 'SMART_PRODUCT_CERTIFICATION.json', root=clone, require_current_code=True),
                       governance=verify_governance(clone), global_integrity=verify_global_integrity(clone, clone / 'SMART_3052_IMPLEMENTATION_GATE.json', clone / 'SMART_GLOBAL_INTEGRITY_PROOF.json'),
                       authority_freshness=audit_freshness(clone), startup=reconcile(clone, include_authority_freshness=True))
        assert receipt['source_fingerprint_stable'] and receipt['scientific_state_unchanged']
    (BASE / 'CERTIFICATION.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({key: receipt[key] for key in ('returncode', 'source_fingerprint_stable', 'scientific_state_unchanged', 'changed_files')}))
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
