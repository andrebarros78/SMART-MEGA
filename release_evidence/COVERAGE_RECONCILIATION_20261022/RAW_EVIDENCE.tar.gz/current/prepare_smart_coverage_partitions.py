"""Prepare disposable same-source checkouts and an independent pytest inventory."""
from __future__ import annotations

import configparser
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/srv/lmcp-data/storage/workspaces/SMART-MEGA-COVERAGE-20261022T0133')
BASE = Path(str(ROOT) + '-evidence') / 'r2'
sys.path.insert(0, str(ROOT))

import pytest
from _pytest.junitxml import mangle_test_address
from smart_global_integrity import REQUIRED_GLOBAL_COVERAGE_SOURCES
from smart_product_certification import code_fingerprint


def git(root, *args):
    return subprocess.run(['git', *args], cwd=root, capture_output=True, text=True, check=True, timeout=60).stdout.strip()


def main():
    assert Path.cwd() == ROOT
    assert git(ROOT, 'status', '--porcelain') == ''
    revision = git(ROOT, 'rev-parse', 'HEAD')
    fingerprint = code_fingerprint(ROOT)
    inventory = []

    class Inventory:
        def pytest_collection_finish(self, session):
            for item in session.items:
                address = mangle_test_address(item.nodeid)
                inventory.append({'nodeid': item.nodeid, 'file': item.nodeid.split('::', 1)[0],
                                  'case': ['.'.join(address[:-1]), address[-1]]})

    result = pytest.main(['--collect-only', '-q', '-p', 'no:cacheprovider', '--disable-warnings'], plugins=[Inventory()])
    assert result == 0 and inventory
    assert len(inventory) == len({item['nodeid'] for item in inventory}) == len({tuple(item['case']) for item in inventory})
    assert code_fingerprint(ROOT) == fingerprint and git(ROOT, 'status', '--porcelain') == ''
    (BASE / 'FRESH_COLLECTION.json').write_text(json.dumps({'source_commit': revision,
        'source_fingerprint_sha256': fingerprint['sha256'], 'pytest_exit_code': int(result), 'items': inventory}, indent=2) + '\n')
    with tarfile.open(ROOT / 'release_evidence/FORENSIC_20261021/RAW_EVIDENCE.tar.gz') as archive:
        old_plan = json.loads(archive.extractfile('raw/PARTITION_PLAN_b04f.json').read())
    old_parts = {row['part']: set(row['files']) for row in old_plan['partitions']}
    files = {item['file'] for item in inventory}
    plans = [{'part': number, 'files': sorted(files & old_parts[number])} for number in range(1, 5)]
    known = set().union(*(set(row['files']) for row in plans))
    for name in sorted(files - known):
        selected = min(plans, key=lambda row: sum(item['file'] in row['files'] for item in inventory))
        selected['files'].append(name)
    for row in plans:
        number = row['part']
        clone = ROOT.with_name(ROOT.name + f'-r2-full-{number}')
        assert not clone.exists()
        subprocess.run(['git', 'clone', '--no-hardlinks', '--branch', git(ROOT, 'branch', '--show-current'), str(ROOT), str(clone)], check=True, capture_output=True, timeout=180)
        git(clone, 'remote', 'set-url', 'origin', 'https://github.com/andrebarros78/SMART-MEGA.git')
        assert git(clone, 'rev-parse', 'HEAD') == revision and git(clone, 'status', '--porcelain') == ''
        assert code_fingerprint(clone) == fingerprint
        out = BASE / f'full-part-{number}'
        out.mkdir()
        config = configparser.ConfigParser()
        config.read(ROOT / '.coveragerc')
        config['run']['parallel'] = 'True'
        config.remove_option('run', 'patch')
        config['run']['data_file'] = str(out / '.coverage')
        config['run']['include'] = '\n' + '\n'.join(str(clone / name) for name in REQUIRED_GLOBAL_COVERAGE_SOURCES)
        with (out / 'coverage.ini').open('w') as stream:
            config.write(stream)
        row.update(root=str(clone), files=sorted(row['files']),
                   expected_nodeids=[item['nodeid'] for item in inventory if item['file'] in row['files']],
                   expected_cases=[item['case'] for item in inventory if item['file'] in row['files']])
    assert sum(len(row['expected_nodeids']) for row in plans) == len(inventory)
    plan = {'schema': 'SMART_FRESH_FULL_REGRESSION_PARTITION_PLAN_1', 'source_commit': revision,
            'source_fingerprint_sha256': fingerprint['sha256'], 'expected_tests': len(inventory), 'partitions': plans,
            'github_actions_used': False}
    (BASE / 'FRESH_PARTITION_PLAN.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps({'source_commit': revision, 'source_fingerprint_sha256': fingerprint['sha256'],
                      'tests': len(inventory), 'partitions': [len(row['expected_cases']) for row in plans]}))


if __name__ == '__main__':
    main()
